#/bin/bash
set -o xtrace

python test_unittest.py #run tests in test_unittest.py, relies on __main__
for x in test*py; do python $x; done #use bash to "discover" tests, relies on __main__
python -m unittest #automatically discovers unittest tests
python -m pytest #automatically discovers pytest & unittest tests
pytest #automatically discovers pytest & unittest tests
pytest test_unittest.py #run tests in test_unittest.py
pytest test_pytest.py::test_bad_input #run test_bad_input in test_pytest.py