class Hallo:
	def __init__(self, wen=None):
		self.instanzvariable = wen

	def grüße(self):
		if self.instanzvariable:
			self.hallo_print(self.instanzvariable)
		else:
			self.hallo_print(self.klassenvariable)

	@staticmethod #Funktion im Modul oft sinnvoller!
	def hallo_print(was):
		print("Hallo", was)

if __name__ == "__main__":
	hallo_julie = Hallo("JULIE Lab")
	hallo_julie.grüße()
	Hallo.hallo_print("Käsekuchen")