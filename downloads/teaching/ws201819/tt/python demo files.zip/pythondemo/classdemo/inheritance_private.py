class Greeter:
	def __init__(self, greeting):
		self.greeting = greeting

	def grüße(self): #wird überschrieben
		print(self.greeting, "?")

	__grüße = grüße #wird nicht überschrieben

class Hallo(Greeter):
	def __init__(self, wen="Welt", greeting="Hallo"):
		super().__init__(greeting) #Konstruktor der Überklasse
		self.wen = wen

	def grüße(self): #überschreibt
		print(self.greeting, self.wen)

	__grüße = grüße #kann nicht überschreiben



if __name__ == "__main__":
	ave = Greeter("Ave")
	ave.grüße()

	hallo_welt = Hallo()
	hallo_welt.grüße()
	#Compiler ersetzt intern Namen
	try:
		hallo_welt.__grüße()
	except Exception as e:
		print(e) 
		print(Hallo.__dict__)
		hallo_welt._Hallo__grüße()
		hallo_welt._Greeter__grüße()

