class Greeter:
	def __init__(self, greeting):
		self.greeting = greeting

	def grüß_jemand(self, wen):
		print(self.__class__.__name__, end="\t")
		print(self.greeting, wen)

	def grüße(self): #besser über abstract base class!
		print(self.__class__.__name__, end="\t")
		raise NotImplementedError("Nicht implementiere Abstratkte Methode")

class Hallo(Greeter):
	def __init__(self, wen="Welt", greeting="Hallo"):
		super().__init__(greeting) #Konstruktor der Überklasse
		self.wen = wen

	def grüße(self):
		self.grüß_jemand(self.wen)


if __name__ == "__main__":
	generic_greeter = Greeter("Ave")
	generic_greeter.grüß_jemand("JULIE Lab")
	try:
		generic_greeter.grüße()
	except NotImplementedError as e:
		print(e)

	hallo_welt = Hallo()
	hallo_welt.grüß_jemand("JULIE Lab")
	hallo_welt.grüße()
