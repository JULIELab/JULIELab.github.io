from collections import namedtuple
from typing import NamedTuple
#from dataclasses import dataclass #nur in 3.7+
import attr

class ClassPoint:
	def __init__(self, x, y):
		self.x = x
		self.y = y

#echte Klasse
@attr.s
class AttrClassPoint:
	x = attr.ib()
	y = attr.ib()

#Attr Nachbau, nur in 3.7+
#@dataclass
#class DataClassPoint:
#	x:int
#	y:int

#Tupellösungen sind langsamer, aber speicherfreundlicher
#Tupel mit netterer Syntax für Zugriff, statt index
TuplePoint = namedtuple("TuplePoint", ["x", "y"])

#effektiv auch nur namedtuple, aber andere Syntax
class FancyTuplePoint(NamedTuple):
	x:int #type hint
	y:int	

	def foo(self): #kann methoden haben
		print("\n",self.x, self.y, "\n")

def test_point(point):
	print(type(point).__name__, "Zugriff", end="\t")
	print(point.x)
	print(type(point).__name__, "Änderung", end="\t")
	try:
		point.x = "Wert änderbar"
		print(point.x)
	except Exception as e:
		print(e)
	print(type(point).__name__, "Iteration", end="\t")
	try:
		print(" ".join([str(a) for a in point]))
	except Exception as e:
		print(e)

if __name__ == "__main__":
	test_point(ClassPoint(1,1))
	test_point(AttrClassPoint(2,2))
	test_point(TuplePoint(3,3))
	test_point(FancyTuplePoint("4",4))

	FancyTuplePoint(4,4).foo()

	print(ClassPoint(1,1) == ClassPoint(1,1))
	print(AttrClassPoint(2,2) == AttrClassPoint(2,2))
	print(TuplePoint(3,3) == TuplePoint(3,3))
	print(FancyTuplePoint(4,4) == FancyTuplePoint(4,4))
