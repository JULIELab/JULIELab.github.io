from memory_profiler import memory_usage, profile

@profile
def my_func():
    a = [1] * (10 ** 6)
    b = [2] * (10 ** 8)
    del b
    return a

if __name__ == '__main__':
    memory_usage((my_func,))
    #besser: python -m memory_profiler SCRIPT (und ohne die imports oben, aber mit @profile)