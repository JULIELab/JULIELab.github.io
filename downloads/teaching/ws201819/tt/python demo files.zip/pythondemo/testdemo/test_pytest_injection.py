import pytest
from tested import only_even
import sys

@pytest.fixture
def testList():
	return [1,2,3]
    

@pytest.fixture
def testGenerator():
	print("\nsetup")
	for x in [4, 5, 6]:
		print("passing", x)
		yield x
	print("teardown") #z.B. File schließen, with kompatibel

@pytest.fixture
def badInput():
	return [1, "2"]

def test_only_even_with_list():
	result = only_even(testList())
	assert result == [2]

def test_only_even_with_generator(capsys):
	with capsys.disabled(): #pytest schluckt stdout/err
		result = only_even(testGenerator())
		assert result == [4, 6]

def test_bad_input():
	with pytest.raises(ValueError):
		only_even(badInput())

def not_a_test():
	assert int("1") == 2

def test_which_fails():
	not_a_test()

if __name__ == '__main__':
    pytest.main()