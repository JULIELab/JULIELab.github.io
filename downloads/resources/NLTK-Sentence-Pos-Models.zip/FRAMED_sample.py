# imports
import nltk
import pickle
# As far as I can see, there is a bug in nltk.data.load, the encoding is not used in the actual loading step (line 755),
# thus the default encoder in python3, utf8, is used and fails in this case with a correct, but rather useless message.
# Instead, we need to load the pickled nltk.PunktSentenceTokenizer class (for the sentence splitter) or the
# nltk.ClassifierBasedPOSTagger (for the PoS tagger, which internally holds a MEGAM model) directly via the pickle module.
# This is in an example for how to do this.

# load sentence splitter
with open('Framed_Punkt_Sentence_model.pickle', 'rb') as f:
    tokenizer = pickle.load(f, encoding='latin1') # the encoding is the key here!

# load POS tagger
with open('Framed_MEGAM_POS_model.pickle', 'rb') as f:
    pos_tagger = pickle.load(f, encoding='latin1') # same encoding as above

# example
sentence = 'Hello World. This is a test. Angeblich funktioniert das auch auf deutsch. Wäre ja auch sonst sehr ärgerlich.'

sent = tokenizer.tokenize(sentence)
token = [nltk.word_tokenize(s) for s in sent]
pos = [print(pos_tagger.tag(t)) for t in token]

print(pos)
