def info(x):
	print(type(x), x, "inhalt:", [y for y in x])

my_input = [1, 2, 3, 1]

#Arten
info([x for x in my_input]) #list
info({x: x for x in my_input}) #dict
info({x for x in my_input}) #set
info((x for x in my_input)) #generator

#mapping
info([x+1 for x in my_input])

#if
info([x for x in my_input if x % 2 == 0]) #Bedingung für x

#Ternärer Operator in Python
x = 1 if True else 0
print(x)
info([x if x % 2 == 0 else "ungerade" for x in my_input]) 

#mehrere schleifen
complex_input = [(1,2), (3,4)]
info([x for x in complex_input]) #eine schleife
info([y for x in complex_input for y in x]) #von links nach rechts lesen
