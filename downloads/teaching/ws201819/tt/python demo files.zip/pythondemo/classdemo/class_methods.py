class Hallo:
	klassenvariable = "Welt" #static in Java
	def __init__(self, wen=None):
		self.instanzvariable = wen

	@classmethod #schlechte Methode
	def class_grüße(cls):
		try:
			print("Hallo", cls.instanzvariable) #Zugriff unmöglich
		except Exception as e:
			print(e)
			print("Hallo", cls.klassenvariable) #Zugriff möglich

	@classmethod #typische Verwendung
	def create_greeter(cls, wen):
		return cls(wen)


if __name__ == "__main__":
	hallo_julie = Hallo("JULIE Lab")
	hallo_julie.class_grüße() 

	hallo_foo = Hallo.create_greeter("foo")
	print(hallo_foo.__dict__)

