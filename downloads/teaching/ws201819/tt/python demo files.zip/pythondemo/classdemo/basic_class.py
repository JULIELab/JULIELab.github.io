class Hallo:
	klassenvariable = "Welt" #static in Java
	def __init__(self, wen=None):
		self.instanzvariable = wen


	def grüße(self):
		if self.instanzvariable:
			print("Hallo", self.instanzvariable)
		else:
			print("Hallo", self.klassenvariable)


if __name__ == "__main__":
	hallo_welt = Hallo()
	hallo_welt.grüße()

	hallo_julie = Hallo("JULIE Lab")
	hallo_julie.grüße()