def info(x):
	print(type(x), "inhalt:", [y for y in x])

input1 = [1, 2, 3, 1]
input2 = "a b c d".split()


info(zip(input1, input2)) #iterieren über Tupel aus Input mit gleichem Index (z.B. Vorhersagen und Soll)
info(enumerate(input1)) #Inhalt mit Index
info(sorted(input1)) #sortierte Liste, Kopie
info(input1)#unverändert

is_even = lambda x: x % 2 == 0 #lambdas
even_in_input1 = [is_even(x) for x in input1]
info(even_in_input1)

#any / all testen auf Wahrheit der Elemente
print("Mindestens einer gerade?", any(even_in_input1))
print("Alle gerade?", all(even_in_input1))

#besser comprehensions nehmen als diese beiden
info(filter(is_even, input1))
info(map(lambda x: x+1, input1)) 