def decorator(func):
	def wrapper():
		print("Dekoriert") #z.B. Logging
		return func()
	return wrapper

def func1():
	print("func1")

@decorator
def func2():
	print("func2")

if __name__ == '__main__':
	func1()
	func2()
	func1 = decorator(func1)
	func1()
