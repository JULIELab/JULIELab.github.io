class Greeter:
	def __init__(self, greeting):
		self.greeting = greeting

	def grüß_jemand(self, wen):
		print(self.__class__.__name__, end="\t")
		print(self.greeting, wen)

class Foo:
	def bar(self):
		print(self.__class__.__name__, end="\t")
		print("bazz")

	def grüß_jemand(self, wen):
		print(self.__class__.__name__, end="\t")
		print("Hard to call me...", wen)

class Hallo(Greeter, Foo): #Links vor rechts
	def __init__(self, wen="Welt", greeting="Hallo"):
		super().__init__(greeting) #Konstruktor der Überklasse
		self.wen = wen

	def grüße(self):
		self.grüß_jemand(self.wen)

	def foo_grüße(self):
		Foo.grüß_jemand(self, self.wen)


if __name__ == "__main__":
	Foo().bar()

	hallo_welt = Hallo(greeting="Hi", wen="du da")
	hallo_welt.grüß_jemand("JULIE Lab")
	hallo_welt.grüße()
	hallo_welt.foo_grüße()
	hallo_welt.bar()
