import abc #abstract base classes
from abc import abstractmethod

class Greeter(abc.ABC):
	def grüß_jemand(self, greeting, wen):
		print(self.__class__.__name__, end="\t")
		print(greeting, wen)

	@abstractmethod
	def grüße(self):
		pass

class Foo(abc.ABC):
	def bar(self):
		print(self.__class__.__name__, end="\t")
		print("bazz")

class Hallo(Greeter, Foo):
	def __init__(self, wen="Welt", greeting="Hallo"):
		self.greeting = greeting
		self.wen = wen

	def grüße(self):
		self.grüß_jemand(self.greeting, self.wen)


if __name__ == "__main__":
	try:
		generic_greeter = Greeter()
	except Exception as e:
		print(e)

	hallo_welt = Hallo()
	hallo_welt.grüß_jemand("Hey", "JULIE Lab")
	hallo_welt.grüße()
	hallo_welt.bar()
