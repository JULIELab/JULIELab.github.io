import unittest
from tested import only_even

class MyTestCase(unittest.TestCase):

	def setUp(self):
		self.testList = [1,2,3]
		self.testGenerator = (x for x in [4, 5, 6])
		self.badInput = [1, "2"]

	def test_only_even_with_list(self):
		result = only_even(self.testList)
		self.assertEqual(result, [2])

	def test_only_even_with_generator(self):
		result = only_even(self.testGenerator)
		self.assertEqual(result, [4, 6])

		self.assertTrue(result == [4, 6])
		self.assertFalse(result == [4])

	def test_bad_input(self):
		with self.assertRaises(ValueError):
			only_even(self.badInput)

	def test_which_fails(self):
		self.assertEqual(int("1"),2)

if __name__ == '__main__':
    unittest.main()