def only_even_loop(r):
	result = []
	for x in range(r):
		if x % 2 == 0:
			result.append(x)
	return result

def only_even_listcomp(r):
	return [x for x in range(r) if x % 2 == 0]

def only_even_filter(r):
	return list(filter(lambda x: x % 2 == 0, range(r)))

def double_loop(r):
	result = []
	for x in range(r):
		result.append(x*2)
	return result

def double_listcomp(r):
	return [x*2 for x in range(r)]

def double_map(r):
	return list(map(lambda x: x*2, range(r)))

r = 10000000 #10M

def comparison_filtering():
	t1 = only_even_loop(r)
	t2 = only_even_listcomp(r)
	t3 = only_even_filter(r)

def comparison_double():
	t1 = double_loop(r)
	t2 = double_listcomp(r)
	t3 = double_map(r)

if __name__ == "__main__":
	import cProfile #schnell, nur profile ist lahm
	cProfile.run("comparison_filtering()") 
	cProfile.run("comparison_double()")
	#alternativ: python -m cProfile SKRIPT (mit main, aber dann kein cProfile.run im Skript!)