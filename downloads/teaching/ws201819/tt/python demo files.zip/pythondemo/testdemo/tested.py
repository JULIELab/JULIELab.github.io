def only_even(iterable):
	"""Generator of even integers in iterable, assumes iterable of ints
	>>> only_even([1,2,3])
	[2, 3]
	"""
	result = []
	for x in iterable:
		if not isinstance(x,int):
			raise ValueError(x, "is not an integer")
		if x % 2 == 0:
			result.append(x)
	return result

if __name__=="__main__":
	import doctest
	doctest.testmod(verbose=True)